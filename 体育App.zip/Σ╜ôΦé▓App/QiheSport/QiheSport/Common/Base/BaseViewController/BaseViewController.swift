//
//  BaseViewController.swift
//  EmptyPro
//
//  Created by Alucardulad on 2/26/20.
//  Copyright © 2020 Alucardulad. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import Kingfisher

class BaseViewController: UIViewController {

    @objc internal func buttonClick(sender: UIButton) { }



//    /// 支持旋转
//    open override var shouldAutorotate: Bool {
//        return false
//    }
//
//
//    /// 支持旋转的方向
//    open override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
//        return .portrait
//    }
    
    override public init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?){
        super.init(nibName: nibNameOrNil,bundle:nibBundleOrNil)
        self.modalPresentationStyle = .fullScreen
    }

    required init?(coder: NSCoder){
        super.init(coder: coder)
        self.modalPresentationStyle = .fullScreen
    }


    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = viewBackGroundColor
        self.navigationController?.navigationBar.barTintColor = UIColor.white
        
        self.automaticallyAdjustsScrollViewInsets = false
        
        remakePopGestureRecognizer()
        
        setUpInterface()
        
        setUpNavigationBar()
        
        loadData()
        

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
//        print("将要显示的是" + String(format: "%@", self))
//        JYProgressHUDTool.shared.dismissProgressHUD()

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
//        print("当前显示的是" + String(format: "%@", self))
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.resignFirstResponder()
//        JYProgressHUDTool.shared.dismissProgressHUD()

//        print("将要离开视野的是" + String(format: "%@", self))
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
//        print("当前离开视野的是" + String(format: "%@", self))
    }


    deinit {

        print(String(format: "%@", self) + "被销毁了")
        
        NotificationCenter.default.removeObserver(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        print(String(format: "%@", self) + "接收到内存警告")
    }
    
    override var prefersStatusBarHidden: Bool {
        return false
    }
}

extension BaseViewController {
    /** 初始化界面 */
    @objc func setUpInterface() {
        //  子类重写该方法，就不用每个子类都单独调用
    }
    
    /** 初始化导航条 */
    @objc func setUpNavigationBar() {
        //  子类重写该方法，就不用每个子类都单独调用
    }
    
    @objc func loadData() {
        
    }
    
    @objc fileprivate func presentLoginVC() {
    }
}

extension BaseViewController : UIGestureRecognizerDelegate {
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        return self.navigationController?.children.count != 1;
    }
    
    fileprivate func remakePopGestureRecognizer() {
        self.navigationController?.interactivePopGestureRecognizer?.delegate = self as UIGestureRecognizerDelegate
    }
}
