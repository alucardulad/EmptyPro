//
//  ColorConfig.swift
//  remakeMushu
//
//  Created by 林君扬 on 2017/11/15.
//  Copyright © 2017年 JYangLin. All rights reserved.
//

import Foundation
import UIKit

/// 0xF9F9F9
let viewBackGroundColor = UIColor.colorWithString(colorString: "0xF9F9F9")


//let KeyDominantColor = JYTool.getBundleNameSpeace() == bangBundleID ? UIColor.colorWithString(colorString: "0x00B9F5") : UIColor.colorWithString(colorString: "0x5BB43B")
