//
//  JYTool.swift
//  baisibudejie
//
//  Created by 林君扬 on 2016/12/23.
//  Copyright © 2016年 linjunyang. All rights reserved.
//

import UIKit

private let JYAppVersion = "JYAppVersion"

 let UPLOADIMGWIDE = CGFloat(1080)
///图片压缩默认比例2000
let IMGScalingW = 2000
/// TabBar高度
let TabBarHeight = JYTool.getTabBarHeight()
/// 导航条高度
let NavigationHeight : CGFloat = 44
///
let TabBarNormalHeight: CGFloat = 49
/// 导航条最大Y值
let NavigationMaxY = JYTool.getNavigationMaxY()
/// 状态栏最大Y值
let StatusBarMaxY : CGFloat = 20

let NavigationSafeHeight : CGFloat = JYTool.getNaviBarSafeHeight()
let BottomSafeHeight : CGFloat = JYTool.getTabBarSafeHeight()
let TabBarSafeHeight : CGFloat = 34

// 条形码生成宽度
var BarCodeWidth: CGFloat = UIScreen.main.bounds.size.width - 108 * JYTool.getScaleWithIphone6Width()

/// 条形码生成高度
var BarCodeHeight: CGFloat = 130 * JYTool.getScaleWithIphone6Width()

var qrCodeBounds:CGFloat = 100

/// 屏幕宽度
let ScreenWidth = UIScreen.main.bounds.size.width
/// 屏幕高度
let ScreenHeight = UIScreen.main.bounds.size.height

/// 获取从Iphone6转换到当前设备的屏幕宽度比例
let getScaleFromIphone6 = JYTool.getScaleWithIphone6Width()

/// 获取当前版本号
let currentVersion = JYTool.getAppVersion()

/// 获取当前命名空间
let currentNameSpeace = JYTool.getNameSpeace()

let currentApplication = UIApplication.shared

let userDefaults = UserDefaults.standard

//  MARK:- 屏幕适配相关
class JYTool {
    
    /// 以iPhone6屏幕宽度进行屏幕适配
    ///
    /// - Returns: 屏幕宽度缩放比例
    class func getScaleWithIphone6Width() -> CGFloat {
        
        let width = UIScreen.main.bounds.size.width
        
        return width / 375.00
    }
    
    /// 以iPhone6屏幕高度进行屏幕适配
    ///
    /// - Returns: 屏幕高度缩放比例
    class func getScaleWithIphone6Height() -> CGFloat {
        
        let height = UIScreen.main.bounds.size.height
        
        return height / 667.00
    }
    
    /// 判断是否是iPhoneX
    class func isIphoneX() -> Bool {
        return (ScreenHeight == 812.00 && ScreenWidth == 375.000000) || (ScreenHeight == 896.000000 && ScreenWidth == 414.000000) ? true : false
    }
    
    /// 获取TabBar高度
    class func getTabBarHeight() -> CGFloat {
        return isIphoneX() ? TabBarNormalHeight + TabBarSafeHeight : TabBarNormalHeight
    }
    
    class func getTabBarSafeHeight() -> CGFloat {
        return isIphoneX() ? 25 : 0
    }
    
    /// 获取Navigation最大Y值
    class func getNavigationMaxY() -> CGFloat {
        return getNaviBarSafeHeight() + 64
    }
    
    class func getNaviBarSafeHeight() -> CGFloat {
        return isIphoneX() ? 25 : 0
    }
}

//  MARK: - 信息验证相关(判断手机号、邮箱等是否正确)
extension JYTool {
    
    class func checkEmail(inputCode : String?) -> Bool {
        guard inputCode != nil else { return false }
        let emailRegex = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$"
        let emailTest: NSPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailTest.evaluate(with: inputCode)
    }
    
    
    class func checkPhone(inputCode : String?) -> Bool {
        guard inputCode != nil else { return false }
        return inputCode!.count == 11 && inputCode!.first == "1"
    }
}

//  MARK: - 系统配置相关（获取版本信息、命名空间等）
extension JYTool {
    
    /// 获取当前版本号
    class func getAppVersion() -> String {
        guard let currentVersion = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as? String else{return "版本号错误"}
        return currentVersion
    }
    
    /// 保存当前版本号到偏好设置
    class func saveAppVersion() {
        UserDefaults.standard.set(JYTool.getAppVersion(), forKey: JYAppVersion)
    }
    
    /// 从偏好设置读取保存的版本号
    class func readAppVersionFromUserDefaults() -> String? {
        return UserDefaults.standard.string(forKey: JYAppVersion)
    }
    
    /// 判断是否是新版本
    class func isNewVersion() -> Bool {
        let currentVersion = getAppVersion()
        let lastVersion = readAppVersionFromUserDefaults() ?? "0.0"
        
        if currentVersion.compare(lastVersion) == ComparisonResult.orderedDescending{
            saveAppVersion()
            return true
        }else{
            return false
        }
    }
    
    /// 获取当前命名空间
    class func getNameSpeace() -> String {
        guard let nameSpeace = Bundle.main.infoDictionary!["CFBundleName"] as? String else {return "命名空间错误"}
        return nameSpeace
    }
    
    /// 获取当前命名空间
    class func getBundleNameSpeace() -> String {
        guard let nameSpeace = Bundle.main.infoDictionary!["CFBundleIdentifier"] as? String else {return "命名空间错误"}
        return nameSpeace
    }
    
    /// 获取手机版本
    class func getPhoneVersion() -> String {
        return "IOS \(UIDevice.current.systemVersion)"
    }
    
//    class func isPoooliOutsideVersion() -> Bool {
//        return JYTool.getBundleNameSpeace() == poooliWithOutsideID
//    }
}

//  MARK: - 根据类名获取类
extension JYTool {
    
    /// 根据类名获取类
    ///
    /// - Parameter className: 类名
    /// - Returns: 类
        /*
         得到返回值后，再转为对应的类型。例如
         JYTool.getClassType(className : “UIViewController”) as? UIViewController.Type
     JYTool.getClassType(className : “UIButton”) as? UIButton.type
        */
    class func getClassTypeWithClassName(className : String) -> AnyClass? {
        //  通过NSClassFromString函数，将类名转化成对应的类。 类名必须是包含命名空间的完整类名，才能转化为对应的类
        return NSClassFromString(currentNameSpeace + "." + className)
    }
}

extension JYTool {
    class func calculateMileage(mileage: Int) -> (mileage: String, unit: String) {
        var danwei = "mm"
        var mileageValue = Double(mileage)
        
        var mileageString = "\(Int(mileageValue))"
        
        if  mileageValue > 100 && mileageValue < 1000 {
            mileageValue = mileageValue / 10.0
            mileageString = String(format: "%.1f", mileageValue)
            danwei = "cm"
        }else if mileageValue >= 1000 && mileageValue <= 1000 * 1000 {
            mileageValue = mileageValue / 1000.0
            
            if mileageValue < 10 {
                mileageString = String(format: "%.2f", mileageValue)
            }else if mileageValue >= 10 && mileageValue < 100{
                mileageString = String(format: "%.1f", mileageValue)
            }else{
                mileageString = "\(Int(mileageValue))"
            }
            danwei = "m"
            
        }else if mileageValue > 1000 * 1000 {
            mileageValue = mileageValue / (1000 * 1000.0)
            if mileageValue < 10 {
                mileageString = String(format: "%.2f", mileageValue)
            }else if mileageValue >= 10 && mileageValue < 100{
                mileageString = String(format: "%.1f", mileageValue)
            }else{
                mileageString = "\(Int(mileageValue))"
            }
            danwei = "Km"
        }
        return (mileageString, danwei)
    }
}

extension JYTool
{
   class func integer(from hexStr: String) -> Int {
        var sum = 0
        // 整形的 utf8 编码范围
        let intRange = 48...57
        // 小写 a~f 的 utf8 的编码范围
        let lowercaseRange = 97...102
        // 大写 A~F 的 utf8 的编码范围
        let uppercasedRange = 65...70
        for c in hexStr.utf8CString {
            var intC = Int(c.byteSwapped)
            if intC == 0 {
                break
            } else if intRange.contains(intC) {
                intC -= 48
            } else if lowercaseRange.contains(intC) {
                intC -= 87
            } else if uppercasedRange.contains(intC) {
                intC -= 55
            } else {
                assertionFailure("输入字符串格式不对，每个字符都需要在0~9，a~f，A~F内")
            }
            sum = sum * 16 + intC
        }
        return sum
    }
}
