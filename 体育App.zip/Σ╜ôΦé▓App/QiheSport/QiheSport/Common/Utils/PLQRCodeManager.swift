//
//  PLQRCodeManager.swift
//  Poooli
//
//  Created by 吴思达 on 2019/11/20.
//  Copyright © 2019 JYLin. All rights reserved.
//

import UIKit

class PLQRCodeManager: NSObject {
    /// 文字生成二维码
    /// - Parameter codeString: 文字
    /// - Parameter fgImage: 插入的图片
    class func generateQRCodeImage(codeString: String, fgImage: UIImage?) -> UIImage? {
        let filter = CIFilter(name: "CIQRCodeGenerator")

        // 1.2 恢复默认设置
        filter?.setDefaults()

        // 1.3 设置生成的二维码的容错率
        // value = @"L/M/Q/H"
        filter?.setValue("H", forKey: "inputCorrectionLevel")

        // 2.设置输入的内容(KVC)
        // 注意:key = inputMessage, value必须是NSData类型
        let inputData = codeString.data(using: String.Encoding.utf8)
        filter?.setValue(inputData, forKey: "inputMessage")

        // 3. 获取输出的图片
        guard let outPutImage = filter?.outputImage else { return nil }

        // 4. 获取高清图片
        let hdImage = getHDImage(outPutImage)

        // 5. 判断是否有前景图片
        if fgImage == nil {
            return hdImage
        }

        return getResultImage(hdImage: hdImage, fgImage: fgImage!)
    }

    /// 生成带Poooli水印二维码
    /// - Parameter codeString: 文本
    class func generateQRCodImageWithPoooliIcon(codeString: String) -> UIImage? {
        let fgImage = UIImage(named: "qrCod_logo")
        let image = generateQRCodeImage(codeString: codeString, fgImage: fgImage)
        return image
    }

    /// 条形码
    /// - Parameter message: 条形码文本
    /// - Parameter code: 编码方式
    /// - Parameter size: 大小
    class func generateBarCodeImage(message: String, code: String, size: CGSize?) -> UIImage? {
        let gen = RSUnifiedCodeGenerator.shared
        
        guard let image = gen.generateCode(message, machineReadableCodeObjectType: code) else { return nil }

        let resultImage = drawBarcodeWithMessage(barCodeImage: image, message: message)

        return resultImage
    }

    class func drawBarcodeWithMessage(barCodeImage: UIImage, message: String) -> UIImage {
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let font = UIFont.systemFont(ofSize: 15 * getScaleFromIphone6)
        let attributes: [NSAttributedStringKey: Any] = [
            .font: font,
            .foregroundColor: normalTextColor,
            .paragraphStyle: paragraphStyle,
        ]

        let width = BarCodeWidth

        let labelHeight = ceil(message.boundingRect(
            with: CGSize(width: width, height: CGFloat.greatestFiniteMagnitude),
            options: [.truncatesLastVisibleLine, .usesLineFragmentOrigin],
            attributes: [NSAttributedStringKey.font: font],
            context: nil).height)

        let height = labelHeight + BarCodeHeight

        let size = CGSize(width: CGFloat(width), height: height + 2)
        UIGraphicsBeginImageContextWithOptions(size, false, UIScreen.main.scale)
        barCodeImage.draw(in: CGRect(x: 0, y: 0, width: size.width, height: BarCodeHeight))
        message.draw(
            in: CGRect(x: 0, y: BarCodeHeight + 2, width: BarCodeWidth, height: labelHeight),
            withAttributes: attributes)
        guard let resultImage = UIGraphicsGetImageFromCurrentImageContext() else { return UIImage() }
        UIGraphicsEndImageContext()
        return resultImage
    }
}

/// 调整图片清晰度
/// - Parameter outImage: 原图
fileprivate func getHDImage(_ outImage: CIImage) -> UIImage {
    let transform = CGAffineTransform(scaleX: 10, y: 10)
    // 放大图片
    let ciImage = outImage.transformed(by: transform)

    return UIImage(ciImage: ciImage)
}

// 获取前景图片
fileprivate func getResultImage(hdImage: UIImage, fgImage: UIImage) -> UIImage {
    let hdSize = hdImage.size
    // 1. 开启图形上下文
    UIGraphicsBeginImageContextWithOptions(hdSize, true, UIScreen.main.scale)
    // 2. 将高清图片画到上下文
    hdImage.draw(in: CGRect(x: 0, y: 0, width: hdSize.width, height: hdSize.height))

    // 3. 将前景图片画到上下文
    let fgWidth: CGFloat = 80
    fgImage.draw(in: CGRect(x: (hdSize.width - fgWidth) / 2, y: (hdSize.height - fgWidth) / 2, width: fgWidth, height: fgWidth))

    // 4. 获取上下文
    guard let resultImage = UIGraphicsGetImageFromCurrentImageContext() else { return UIImage() }

    // 5. 关闭上下文
    UIGraphicsEndImageContext()

    return resultImage
}
