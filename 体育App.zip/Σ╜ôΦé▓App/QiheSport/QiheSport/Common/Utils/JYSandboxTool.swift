//
//  JYSandboxTool.swift
//  清空缓存
//
//  Created by 林君扬 on 2017/1/18.
//  Copyright © 2017年 linjunyang. All rights reserved.
//

/// 沙盒功能相关工具类

import UIKit
import Kingfisher
extension JYSandboxTool {
    //  MARK:- 获取沙盒路径
    /// 获取沙盒Documents文件夹路径
    func getDocumentsPath() -> String? {
        
        /*
         参数1：获取那个文件夹
         参数2：获取用户沙盒
         参数3：是否展开
         返回值是一个数组，取first或者last都一样
         */
        guard  let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first  else {
            return nil
        }
        
        return documentsPath
    }
    
    /// 获取沙盒Caches文件夹路径
    func getCachesPath() -> String? {



        guard  let cachesPath = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true).first  else {
            return nil
        }
        
        return cachesPath
    }
    
    /// 获取沙盒Temp文件夹路径
    func getTempPath() -> String {
        //  Temp文件夹直接通过调用NSTemporaryDirectory获取
        return NSTemporaryDirectory()
    }
}

extension JYSandboxTool {
    //  MARK:- 拼接沙盒全路径
    /// 根据传入文件名，拼接Documents文件夹全路径
    func appendingPathWithDocuments(fileName : String) -> String? {
        
        guard let path = self.getDocumentsPath() else {
            return nil
        }
        
        /// 如果fileName是一个完整的URL，我们只需要URL最后的文件名和沙盒路径拼接
        /// pathComponents方法, 会按照字符串的『/』来切割字符串, 如果给定的字符串中没有『/』那么就直接返回给定的字符串
        guard let temp = (fileName as NSString).pathComponents.last else {
            return nil
        }
        
        let filePath = (path as NSString).appendingPathComponent(temp)
        return filePath
    }
    
    /// 根据传入文件名，拼接Caches文件夹全路径
    func appendingPathWithCaches(fileName : String) -> String? {
        
        guard let path = self.getCachesPath() else {
            return nil
        }
        
        guard let temp = (fileName as NSString).pathComponents.last else {
            return nil
        }
        
        let filePath = (path as NSString).appendingPathComponent(temp)
        return filePath
    }
}

extension JYSandboxTool {
    //  MARK:- 计算大小
    /// 计算单个文件大小
    ///
    /// - Parameter filePath: 文件全路径
    /// - Returns: 单个文件大小
    func calculateFileSize(filePath : String) -> CGFloat {
        
        //  获取文件管理者
        let fileManager = FileManager.default
        
        //  为了安全，应该判断filePath是否是真的文件全路径
        assert(fileManager.fileExists(atPath: filePath) != false, "filePath不是完整的全路径")
        
        do {
            /// attributesOfItem只适用于计算单个文件大小
            let fileSize = try fileManager.attributesOfItem(atPath: filePath)[FileAttributeKey.size]
            
            return fileSize as! CGFloat
            
        } catch {
            print(error)
            return 0
        }
        
    }
    
    /// 计算文件夹大小
    ///
    /// - Parameter filePath: 文件夹全路径
    /// - Returns: 文件夹大小
    func calculateFilePathSize(folderPath : String, completion : @escaping (_ fileSize : CGFloat)->()) {
        
        let operation = BlockOperation{
            
            //            print(Thread.current)
            
            var fileSize : CGFloat = 0.0
            
            //  获取文件管理者
            let fileManager = FileManager.default
            
            //  为了安全，应该判断filePath是否是真的文件夹全路径
            //        assert(fileManager.fileExists(atPath: filePath) != false, "filePath不是完整的全路径")
            
            //  获取文件夹内文件数组
            guard let fileArray = fileManager.subpaths(atPath: folderPath) else {
                return completion(fileSize)
            }
            
            //  遍历文件夹
            for filePath in fileArray {
                
                //  排除.DS文件
                //            if filePath.contains(".DS") {
                //                continue
                //            }
                
                //  还应该排除是否为文件夹
                /*
                 // 判断是否文件夹
                 BOOL isDirectory;
                 // 判断文件是否存在,并且判断是否是文件夹
                 BOOL isExist = [mgr fileExistsAtPath:filePath isDirectory:&isDirectory];
                 if (!isExist || isDirectory) continue;
                 */
                
                //  拼接完整路径
                let fileAllPath = (folderPath as NSString).appendingPathComponent(filePath)
                
                //  计算文件大小
                fileSize = fileSize + self.calculateFileSize(filePath: fileAllPath)
            }
            
            return completion(fileSize)
        }
        
        let queue = OperationQueue.init()
        queue.addOperation(operation)
    }
    
}

extension JYSandboxTool{
    //  获取cache文件夹大小
    func getImageCachesSize(completion : @escaping (_ fileSize : String)->()) {

        let cache = KingfisherManager.shared.cache
        cache.calculateDiskCacheSize { (size) in
            let ss = Double(size / 1024 / 1024)
            completion(String(format: "%.1f M", ss))
        }
    }
}

extension JYSandboxTool {
    //  MARK:- 路径判断
    /// 确定文件是否存在

    func hasFile(filePath : String) -> Bool {
        //  获取文件管理者
        let fileManager = FileManager.default

        if fileManager.fileExists(atPath: filePath)
        {
            return true
        }
        else{
            return false
        }

    }

}

extension JYSandboxTool {
    //  MARK:- 删除文件
    /// 删除单个文件
    func deleteFile(filePath : String) -> Bool {
        //  获取文件管理者
        let fileManager = FileManager.default
        
        do {
            try fileManager.removeItem(atPath: filePath)
            return true
        } catch  {
            return false
        }
    }
    
    /// 删除文件夹下的所有文件
    func deleteFileOfFolder(folderPath : String) -> Bool {
        //  获取文件管理者
        let fileManager = FileManager.default
        
        //  获取文件夹内文件数组
        guard let fileArray = fileManager.subpaths(atPath: folderPath) else {
            return false
        }
        
        //  遍历文件夹
        for filePath in fileArray {
            //  拼接完整路径
            let fileAllPath = (folderPath as NSString).appendingPathComponent(filePath)
            
            if self.deleteFile(filePath: fileAllPath) {
                continue
            }else{
                return true
            }
        }
        return true
    }
    
    //  MARK:- 快速删除沙盒缓存
    //  因为沙盒缓存都是放在cache文件夹下的，所以我们就cache文件夹下的文件即可
    func deleteCache() -> Bool {

        let cache = KingfisherManager.shared.cache
        cache.clearMemoryCache()
        cache.clearDiskCache()
        cache.cleanExpiredDiskCache()

        guard let path = getCachesPath() else {
            return false
        }
        return deleteFileOfFolder(folderPath: path)
    }
    
    /// 创建本地文件夹
    ///
    /// - Parameter folderName: 文件夹名称
    /// - Returns: 文件夹路径
    func createLocalFolder(folderName: String) -> String {
        let fileManager = FileManager.default
        let localFolderPath = JYSandboxTool.shareTool.appendingPathWithDocuments(fileName: folderName) ?? ""
        var isDirect: ObjCBool = ObjCBool(false)
        let isExist = fileManager.fileExists(atPath: localFolderPath, isDirectory: &isDirect)
        guard isExist && isDirect.boolValue else {
            //非目录
            try? fileManager.createDirectory(atPath: localFolderPath, withIntermediateDirectories: true, attributes: nil)
            return localFolderPath
        }
        return localFolderPath
    }
    
    /// 创建文件夹
    ///
    /// - Parameter floderPath: 文件夹路径
    /// - Returns: 文件夹路径
    func createLocalFolderByPath(floderPath: String) -> String {
        let fileManager = FileManager.default
        var isDirect: ObjCBool = ObjCBool(false)
        let isExist = fileManager.fileExists(atPath: floderPath, isDirectory: &isDirect)
        guard isExist && isDirect.boolValue else {
            //非目录
            try? fileManager.createDirectory(atPath: floderPath, withIntermediateDirectories: true, attributes: nil)
            return floderPath
        }
        return floderPath
    }
    
}



class JYSandboxTool: NSObject {
    
    //  MARK:- 单例
    /// 提供单例
    static let shareTool : JYSandboxTool = JYSandboxTool()
    
}
