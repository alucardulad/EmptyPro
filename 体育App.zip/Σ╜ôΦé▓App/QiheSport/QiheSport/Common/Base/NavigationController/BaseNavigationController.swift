//
//  BaseNavigationController.swift
//  EmptyPro
//
//  Created by Alucardulad on 2/26/20.
//  Copyright © 2020 Alucardulad. All rights reserved.
//

import UIKit
import EachNavigationBar

let navigationBackButtonImageName = "navigationBack_black"
let navigationBackWhiteButtonImageName = "navigationBack_white"
let navigationRightButtonImageName = "JYPrintWrongQuestionBottomToolView_wenzi_dayin_normal"

class BaseNavigationController: UINavigationController, UIGestureRecognizerDelegate {
    
    private(set) lazy var backButtonView: UIView = {
        let backButton = UIButton(type: .custom)
        backButton.setImage(UIImage(named: navigationBackButtonImageName), for: .normal)
        backButton.setImage(UIImage(named: navigationBackButtonImageName), for: .highlighted)
        backButton.sizeToFit()
        backButton.frame.size = CGSize(width: backButton.frame.width, height: NavigationHeight)
        backButton.isUserInteractionEnabled = false
        
        let backButtonView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 40))
        backButtonView.addSubview(backButton)
        
        let tap = UITapGestureRecognizer(target: self, action:  #selector(backButtonClick))
        backButtonView.addGestureRecognizer(tap)
        
        return backButtonView
    }()
    
    override init(rootViewController: UIViewController) {
        super.init(rootViewController: rootViewController)
        self.modalPresentationStyle = .fullScreen
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        self.modalPresentationStyle = .fullScreen
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        remakePopGestureRecognizer()
        
        self.setNavigationBar()
        
//        let newNavigationBar = JYSystemNavigationBar()
//        setValue(newNavigationBar, forKey: "navigationBar")
//        self.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.navigationBar.tintColor = UIColor.white
        
        self.interactivePopGestureRecognizer?.delegate = self
    }
    
}

extension BaseNavigationController {
    @objc fileprivate func backButtonClick() {
        self.view.endEditing(true)
        self.popViewController(animated: true)
    }
}

extension BaseNavigationController {
    
    override func pushViewController(_ viewController: UIViewController, animated: Bool) {
        if self.children.count > 0 {
            viewController.hidesBottomBarWhenPushed = true
            viewController.navigationItem.leftBarButtonItem = UIBarButtonItem(customView: self.backButtonView)
        }
        super.pushViewController(viewController, animated: animated)
    }
    
    fileprivate func setNavigationBar() {
        //        self.navigationBar.barTintColor = KeyRedColor
        
        self.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.black,  NSAttributedString.Key.font:UIFont.systemFont(ofSize: 18)]
    }
    
    override func setViewControllers(_ viewControllers: [UIViewController], animated: Bool) {
        if !viewControllers.isEmpty {
            let viewController = viewControllers.last
            viewController?.hidesBottomBarWhenPushed = true
            viewController?.navigationItem.leftBarButtonItem = UIBarButtonItem(customView: self.backButtonView)
        }
        
        super.setViewControllers(viewControllers, animated: animated)
    }
}
