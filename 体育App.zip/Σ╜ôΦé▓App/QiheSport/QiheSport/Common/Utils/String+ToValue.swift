//
//  String+ToValue.swift
//  Poooli
//
//  Created by JYLin on 2018/12/4.
//  Copyright © 2018年 JYLin. All rights reserved.
//

import UIKit

extension String {
    func floatValue() -> CGFloat {
        return CGFloat(Double(self) ?? 0)
    }
    
    func intValue() -> Int {
        return Int(self) ?? 0
    }
    
    func boolValue() -> Bool {
        return Bool(self) ?? false
    }

    /*
     *去掉所有空格
     */
    var removeAllSapce: String {
        return self.replacingOccurrences(of: " ", with: "", options: .literal, range: nil)
    }
    
    /// 去除表情文字
    ///
    /// - Returns: 字符串
    func disableEmoji()->String{
        do {
            let regex = try NSRegularExpression(pattern: "[^\\u0020-\\u007E\\u00A0-\\u00BE\\u2E80-\\uA4CF\\uF900-\\uFAFF\\uFE30-\\uFE4F\\uFF00-\\uFFEF\\u0080-\\u009F\\u2000-\\u201f\r\n]", options: NSRegularExpression.Options.caseInsensitive)
            let text = self as NSString
            let modifiedString = regex.stringByReplacingMatches(in: text as String, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, text.length), withTemplate: "")
            
            return modifiedString
        } catch {
            print(error)
        }
        return ""
    }
}

// MARK: - 计算string高度
extension String {
    
    /// 计算string高度(不含行间距)
    ///
    /// - Parameters:
    ///   - string: 字符串
    ///   - width: 最大宽度
    ///   - font: 字体大小
    /// - Returns: 字符串高度
    static func caculateStringHeight(string: String,
                                     width: CGFloat,
                                     font: UIFont) -> CGFloat
    {
        let paragraphStyle: NSMutableParagraphStyle = NSMutableParagraphStyle.init()
        paragraphStyle.maximumLineHeight = font.lineHeight
        paragraphStyle.minimumLineHeight = font.lineHeight
        let attribute: Dictionary = [NSAttributedString.Key.font : font]
        let options: NSStringDrawingOptions = NSStringDrawingOptions(rawValue: NSStringDrawingOptions.usesLineFragmentOrigin.rawValue | NSStringDrawingOptions.usesFontLeading.rawValue)
        let size: CGSize = (string as NSString).boundingRect(with: CGSize.init(width: width, height: CGFloat(MAXFLOAT)), options: options, attributes: attribute, context: nil).size
        return size.height
    }
    
    static func caculateStringHeightWithSpace(string: String,
                                              width: CGFloat,
                                              space: CGFloat,
                                              font: UIFont) -> CGFloat
    {
        let paraStyle = NSMutableParagraphStyle.init()
        paraStyle.lineSpacing = space
        let attribute: Dictionary = [NSAttributedString.Key.font : font, NSAttributedString.Key.paragraphStyle : paraStyle]
        let options: NSStringDrawingOptions = NSStringDrawingOptions(rawValue: NSStringDrawingOptions.usesLineFragmentOrigin.rawValue | NSStringDrawingOptions.usesFontLeading.rawValue)
        let size: CGSize = (string as NSString).boundingRect(with: CGSize.init(width: width, height: CGFloat(MAXFLOAT)), options: options, attributes: attribute, context: nil).size
        return size.height
    }
    
}

// MARK: - 绘制图片
extension String {
    
    /// 文字转图片
    ///
    /// - Parameters:
    ///   - text: 文字
    ///   - width: 宽度
    ///   - maxHeight: 每页最大高度
    ///   - textColor: 字体颜色
    ///   - font: 字体大小
    ///   - complete: 完成回调
    static func textToImages(text: String,
                             width: CGFloat,
                             maxHeight: CGFloat,
                             textColor: UIColor = UIColor.black,
                             font: UIFont,
                             complete: @escaping (_ images: Array<UIImage>) -> ())
    {
        if text.isEmpty { return }
        
        let contenSize = CGSize(width: ScreenWidth, height: maxHeight)
        let attributDict = [NSAttributedString.Key.font : font]
        DispatchQueue.global().async {
            
            let pageArray: Array<NSAttributedString> = pagingWithContentString(contentString: text, contentSize: contenSize, textAttribute: attributDict)
            
            var array: Array<UIImage> = []
            
            for (_, string) in pageArray.enumerated() {
                // 开启上下文
                UIGraphicsBeginImageContextWithOptions(CGSize.init(width: width, height: maxHeight), false, UIScreen.main.scale)
                /// 拿到上下文
                guard let ctx = UIGraphicsGetCurrentContext() else { return }
                ctx.setFillColor(UIColor.white.cgColor)
                // 填充绘制
                ctx.fill(CGRect(x: 0, y: 0, width: width, height: maxHeight))
                string.draw(in: CGRect(x: 0, y: 0, width: width, height: maxHeight))
                guard let image = UIGraphicsGetImageFromCurrentImageContext() else { return }
                array.append(image)
                
                UIGraphicsEndImageContext()
            }
            
            complete(array)
        }
    }
    
    static func pagingWithContentString(contentString: String, contentSize: CGSize, textAttribute: Dictionary<NSAttributedString.Key, Any>) -> Array<NSAttributedString> {
        var pageArray: Array<NSAttributedString> = []
        let orginAttributeString = NSAttributedString.init(string: contentString, attributes: textAttribute)
        let textStorage = NSTextStorage.init(attributedString: orginAttributeString)
        let layoutManager = NSLayoutManager()
        textStorage.addLayoutManager(layoutManager)
        var i: Int = 0
        while true {
            i += 1
            let textContainer = NSTextContainer.init(size: contentSize)
            layoutManager.addTextContainer(textContainer)
            let range = layoutManager.glyphRange(for: textContainer)
            
            if range.length <= 0 {
                break;
            }
            
            let str = (contentString as NSString).substring(with: range)
            let attriStr = NSAttributedString.init(string: str, attributes: textAttribute)
            pageArray.append(attriStr)
            
            
        }
        return pageArray
    }
    
    
}

// MARK: - 读取本地文本
extension String {
    
    static func transcodingWithPath(path: String) -> String {
        
        var string = try? String.init(contentsOfFile: path, encoding: String.Encoding.utf8)
        if string != nil {
            return string!
        }
        //如果之前不能解码，现在使用GBK解码
        string = try? String.init(contentsOfFile: path, encoding: String.Encoding.init(rawValue: 0x80000632))
        if string != nil {
            return string!
        }
        
        string = try? String.init(contentsOfFile: path, encoding: String.Encoding.init(rawValue: 0x80000631))
        return string ?? ""
    }
    
    static func transcodingWithUrl(url: URL) -> String {

        if let string = try? String(contentsOf: url, encoding: .utf8) {
            return string
        }
        //如果之前不能解码，现在使用GBK解码
        if let string = try? String(contentsOf: url, encoding: .init(rawValue: 0x80000632)) {
            return string
        }
        
        let string = try? String(contentsOf: url, encoding: .init(rawValue: 0x80000631))
        return string ?? ""
    }
    
}

extension String {
    
    /// 语言本地化
    ///
    /// - Parameter comment: 占位符
    /// - Returns: local string
    func localized(_ comment: String = "") -> String {
        return String.init(format: NSLocalizedString(self, tableName: "Localizable",
                                                     bundle: PLLocalizationManager.standard.bundle!,
                                                     value: "",
                                                     comment: ""), "\(comment)")
    }
}
