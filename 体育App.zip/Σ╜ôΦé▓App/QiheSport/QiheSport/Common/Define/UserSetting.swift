//
//  UserSetting.swift
//  EmptyPro
//
//  Created by Alucardulad on 2/25/20.
//  Copyright © 2020 Alucardulad. All rights reserved.
//

import UIKit

class UserSetting: NSObject {

    //  单例
     static let currentSetting = UserSetting()
     
     fileprivate override init() {
             super.init()
     }
    
}
