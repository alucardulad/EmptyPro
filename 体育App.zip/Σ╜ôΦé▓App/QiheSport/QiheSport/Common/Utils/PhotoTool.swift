//
//  PhotoTool.swift
//  EmptyPro
//
//  Created by Alucardulad on 2/25/20.
//  Copyright © 2020 Alucardulad. All rights reserved.
//

import UIKit
import Photos

class PhotoTool: NSObject {
    class func savePhoto(image: UIImage, finishedCallback : @escaping (_ isSuccess : Bool) -> ()) {
        
        if PHPhotoLibrary.authorizationStatus() == .notDetermined {
            self.requestAuthorization { (_) in
                
            }
            return
        }
        
        if PHPhotoLibrary.authorizationStatus() != .authorized {
            self.showPhotoAuthorizedError()
            return
        }
        
        PHPhotoLibrary.shared().performChanges({
            PHAssetChangeRequest.creationRequestForAsset(from: image)
        }) { (isSuccess: Bool, error: Error?) in
            if error != nil {
                finishedCallback(false)
            } else{
                finishedCallback(true)
            }
        }
    }
    
    class func isAuthorized() -> Bool {
        return PHPhotoLibrary.authorizationStatus() != .authorized
    }
    
    class func requestAuthorization(finishedCallback : @escaping (_ success: Bool) -> ()) {
        PHPhotoLibrary.requestAuthorization({ (status) in
            
            if status == .authorized {
                finishedCallback(true)
            } else if status == .denied || status == .restricted{
                print("点拒绝")
            }
            
        })
    }
    
    class func showPhotoAuthorizedError() {
        let alertVc = UIAlertController(title: "保存失败", message: "请在iPhone的\"设置-隐私-照片\"选项中，允许应用访问你的照片", preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: "好", style: .default, handler: nil)
        alertVc.addAction(cancelAction)
        
        UIApplication.shared.keyWindow?.rootViewController?.children.first?.present(alertVc, animated: true, completion: {
            
        })
    }
}
