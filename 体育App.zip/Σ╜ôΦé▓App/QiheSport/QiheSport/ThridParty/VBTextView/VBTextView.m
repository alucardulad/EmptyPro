//
//  VBTextView.m
//  loadingView
//
//  Created by XiaoYun on 16/3/9.
//  Copyright © 2016年 XiaoYun. All rights reserved.
//

#import "VBTextView.h"

@interface VBTextView ()

@end
@implementation VBTextView

-(void)awakeFromNib{
    [super awakeFromNib];
    [self instalProper];
    [self addObserver];
    [self setPlaceHolder:_placeHolder];
}
-(instancetype)initWithFrame:(CGRect)frame placeHolder:(NSString *)placeHolder{
    if (self=[super initWithFrame:frame]) {
        [self instalProper];
        [self setPlaceHolder:placeHolder];
        [self addObserver];
    }
    return self;
}
-(instancetype)init{
    if (self=[super init]) {
        [self instalProper];
        [self addObserver];
    }
    return self;
}
-(instancetype)initWithFrame:(CGRect)frame{
    if (self=[super initWithFrame:frame]) {
        [self instalProper];
        [self addObserver];
    }
    return self;
}
-(void)instalProper{
    _placeColor=[UIColor lightGrayColor];
  //  _placeHolder=@"请输入内容";
    if (_placeHolder.length<1 ) {
            [self setPlaceHolder:@"请输入内容"];
    }
    _cornerRadius=.0f;
    _borderWitdh=.0f;
    _borderColor=[UIColor clearColor];
    _placeColor=[UIColor lightGrayColor];
    _infoColor=[UIColor blackColor];
    
}
-(void)setPlaceHolder:(NSString *)placeHolder{
    _placeHolder=placeHolder;
    self.text = placeHolder;
    self.textColor = _placeColor;
}
-(void)setPlaceColor:(UIColor *)placeColor{
    _placeColor=placeColor;
}
-(void)setCornerRadius:(CGFloat)cornerRadius{
    _cornerRadius=cornerRadius;
    self.layer.cornerRadius=cornerRadius;
}
-(void)setBorderColor:(UIColor *)borderColor{
    _borderColor=borderColor;
    self.layer.borderColor=_borderColor.CGColor;
}
-(void)setBorderWitdh:(CGFloat )borderWitdh{
    _borderWitdh=borderWitdh;
    self.layer.borderWidth=_borderWitdh;
}
-(void)addObserver
{
    //注册通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didBeginEditing:) name:UITextViewTextDidBeginEditingNotification object:self];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didEndEditing:) name:UITextViewTextDidEndEditingNotification object:self];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(terminate:) name:UIApplicationWillTerminateNotification object:[UIApplication sharedApplication]];
}

- (void)terminate:(NSNotification *)notification {
    //移除通知
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didBeginEditing:(NSNotification *)notification {
    if ([self.text isEqualToString:self.placeHolder]) {
        self.text = @"";
        self.textColor = _infoColor;
    }
}

- (void)didEndEditing:(NSNotification *)notification {
    if (self.text.length<1) {
        self.text = self.placeHolder;
        self.textColor = _placeColor;
    }
}
-(void)dealloc{
    NSLog(@"dealloc");
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
/**
 比较两个版本号的大小

 @param v1 第一个版本号
 @param v2 第二个版本号
 @return 版本号相等,返回0; v1小于v2,返回-1; 否则返回1.
 */
+ (NSInteger)compareVersion2:(NSString *)v1 to:(NSString *)v2 {
    // 都为空，相等，返回0
    if (!v1 && !v2) {
        return 0;
    }
    // v1为空，v2不为空，返回-1
    if (!v1 && v2) {
        return -1;
    }
    // v2为空，v1不为空，返回1
    if (v1 && !v2) {
        return 1;
    }
    // 获取版本号字段
    NSArray *v1Array = [v1 componentsSeparatedByString:@"."];
    NSArray *v2Array = [v2 componentsSeparatedByString:@"."];
    // 取字段最大的，进行循环比较
    NSInteger bigCount = (v1Array.count > v2Array.count) ? v1Array.count : v2Array.count;

    for (int i = 0; i < bigCount; i++) {
        // 字段有值，取值；字段无值，置0。
        NSInteger value1 = (v1Array.count > i) ? [[v1Array objectAtIndex:i] integerValue] : 0;
        NSInteger value2 = (v2Array.count > i) ? [[v2Array objectAtIndex:i] integerValue] : 0;
        if (value1 > value2) {
            // v1版本字段大于v2版本字段，返回1
            return 1;
        } else if (value1 < value2) {
            // v2版本字段大于v1版本字段，返回-1
            return -1;
        }
        // 版本相等，继续循环。
    }
    // 版本号相等
    return 0;

}


@end
