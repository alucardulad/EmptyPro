//
//  UIView-Extension.swift
//  remakeMushu
//
//  Created by 林君扬 on 2018/3/26.
//  Copyright © 2018年 JYangLin. All rights reserved.
//

import UIKit

extension UIView {
    func removeAllSubViews() {
        for view in self.subviews {
            view.removeFromSuperview()
        }
    }
}

// MARK: - 截屏
extension UIView {


    class  func setShadow(view:UIView,width:CGFloat,bColor:UIColor,
                   sColor:UIColor,offset:CGSize,opacity:Float,radius:CGFloat) {

        //设置视图边框宽度
        view.layer.borderWidth = width
        //设置边框颜色
        view.layer.borderColor = bColor.cgColor
        //设置边框圆角
        view.layer.cornerRadius = radius
        //设置阴影颜色
        view.layer.shadowColor = sColor.cgColor
        //设置透明度
        view.layer.shadowOpacity = opacity
        //设置阴影半径
        view.layer.shadowRadius = radius
        //设置阴影偏移量
        view.layer.shadowOffset = offset

    }

    
    /// 截屏，调用的View多大就截取多大范围
    func screenshot() -> UIImage? {
        return self.screenshot(clipRect: self.bounds)
    }
    
    /// 截屏
    ///
    /// - Parameters:
    ///   - clipRect: 截取的大小
    ///   - rect: 原始大小
    func screenshot(clipRect: CGRect, rect: CGRect = CGRect.zero) -> UIImage? {
        var rect = rect
        if rect == CGRect.zero {
            rect = self.bounds
        }
        
        UIGraphicsBeginImageContext(rect.size)
        
        let path = UIBezierPath(rect: clipRect)
        path.addClip()
        
        guard let ctx = UIGraphicsGetCurrentContext() else {
            return nil
        }
        self.layer.render(in: ctx)
        
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
        return newImage
    }
    
    /// 获取顶部控制器
    func topViewController() -> UIViewController? {
        guard let keyWindow = UIApplication.shared.keyWindow else { return nil }
        var topVC = keyWindow.rootViewController
        guard topVC != nil else { return nil }
        while (topVC?.presentedViewController) != nil {
            topVC = topVC!.presentedViewController
        }

        if topVC!.isKind(of: UINavigationController.self) {
            topVC = (topVC as! UINavigationController).topViewController
        }

        if topVC!.isKind(of: UITabBarController.self) {
            topVC = (topVC as! UITabBarController).selectedViewController
        }

        return topVC
    }
}
