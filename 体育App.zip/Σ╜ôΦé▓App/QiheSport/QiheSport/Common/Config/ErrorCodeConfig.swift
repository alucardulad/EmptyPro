//
//  ErrorCodeConfig.swift
//  Poooli
//
//  Created by 林君扬 on 2019/2/18.
//  Copyright © 2019 JYLin. All rights reserved.
//

import Foundation


/// 数据类型转换失败
let extensionModelErrorCode = 91000100

/// 没有网路
let netWorkError = 9900900

/// 请求成功
let requestSuccessCode = 200

/// 用户需要登录、token过期
let needLogionCode = 1015

/// 下载文件成功
let downLoadSuccessCode = 200
/// 下载文件失败
let downLoadErrorCode = 401401401

/// 上传文件成功
let uploadSuccessCode = 200
/// 上传文件失败
let uploadErrorCode = 400400400

/// 设备激活序列号无效
let requestActivateDeviceNumberError = 1018
/// 设备激活，该设备已经被激活
let requestActivateDeviceNumberActivaed = 1019

let requestPhoneNumberError = 1003
