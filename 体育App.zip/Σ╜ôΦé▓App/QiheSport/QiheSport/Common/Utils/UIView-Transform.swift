//
//  UIView-Tranform.swift
//  dome
//
//  Created by pba on 2018/2/1.
//  Copyright © 2018年 JYangLin. All rights reserved.
//

import UIKit

//  MARK:- 平移形变
extension UIView {
    
    ///  以初始状态，发生平移形变
    ///
    /// - Parameters:
    ///   - left: 向左平移距离
    ///   - right: 向右平移距离
    ///   - top: 向上平移距离
    ///   - bottom: 向下平移距离
    func translateFromInitialState(left: CGFloat = 0, right: CGFloat = 0, top: CGFloat = 0, bottom: CGFloat = 0) {
        
        let x = right - left
        let y = bottom - top
        self.transform = CGAffineTransform(translationX: x, y: y)
    }
    
    ///  以当前状态，发生平移形变
    ///
    /// - Parameters:
    ///   - left: 向左平移距离
    ///   - right: 向右平移距离
    ///   - top: 向上平移距离
    ///   - bottom: 向下平移距离
    func translateFromCurrentState(left: CGFloat = 0, right: CGFloat = 0, top: CGFloat = 0, bottom: CGFloat = 0) {
        let x = right - left
        let y = bottom - top
        self.transform = self.transform.translatedBy(x: x, y: y)
    }
}

//  MARK: - 旋转形变
extension UIView {
    
    /// 以初始状态，发生旋转形变
    ///
    /// - Parameter rotationAngle: 旋转角度
    func rotateFormInitialState(rotationAngle: CGFloat) {
        self.transform = CGAffineTransform(rotationAngle: rotationAngle)
    }
    
    /// 以当前状态，发生旋转形变
    ///
    /// - Parameter rotationAngle: 旋转角度
    func rotateFormCurrentState(rotationAngle: CGFloat) {
        self.transform = self.transform.rotated(by: rotationAngle)
    }
}

//  MARK: - 缩放
extension UIView {
    
    /// 以初始状态，发生缩放形变
    ///
    /// - Parameters:
    ///   - scaleX: x方向缩放比例，不缩放比例为1
    ///   - y: y方向缩放比例
    func scaledFromInitialState(scaleX: CGFloat, y: CGFloat) {
        self.transform = CGAffineTransform(scaleX: scaleX, y: y)
    }
    
    /// 以初始状态，发生缩放形变
    ///
    /// - Parameters:
    ///   - scaleX: x方向缩放比例，不缩放比例为1
    ///   - y: y方向缩放比例
    func scaledFromCurrentState(scaleX: CGFloat, y: CGFloat) {
        self.transform = self.transform.scaledBy(x: scaleX, y: y)
    }
}
