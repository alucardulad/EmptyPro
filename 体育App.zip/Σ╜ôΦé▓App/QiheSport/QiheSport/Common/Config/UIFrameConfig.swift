//
//  UIFrameConfig.swift
//  Poooli
//
//  Created by 林君扬 on 2019/3/8.
//  Copyright © 2019 JYLin. All rights reserved.
//

import UIKit

/// 默认间距，之后UI间距基本都能是间距的倍数：0.5倍，1倍，1、5倍等
let normalSpacing = 10 * getScaleFromIphone6

//玩纸条为了防止字体超出设置边距。
let PortraitEditPageSpacing = 20 * getScaleFromIphone6
