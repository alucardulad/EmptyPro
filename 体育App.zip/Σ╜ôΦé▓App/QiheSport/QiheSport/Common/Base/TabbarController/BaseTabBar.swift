//
//  BaseTabBar.swift
//  EmptyPro
//
//  Created by Alucardulad on 2/26/20.
//  Copyright © 2020 Alucardulad. All rights reserved.
//

import UIKit

class BaseTabBar: UITabBar {
    
    fileprivate var addButton: UIButton?

    fileprivate var nowSelectedItem: UIControl?

    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.backgroundColor = .white
        

//        for item in self.subviews {
//            if item.isKind(of: NSClassFromString("UITabBarButton")!) == false && item.isKind(of: NSClassFromString("UIButton")!) == false {
//                for subView in item.subviews {
//                    if subView.isKind(of: NSClassFromString("UIImageView")!) {
//                        subView.backgroundColor = UIColor.black
//                    }
//                }
//            }
//        }
//
//        var itemArray = [AnyObject]()
//        for item in self.subviews {
//            if item.isKind(of: NSClassFromString("UITabBarButton")!) {
//                itemArray.append(item)
//            }
//        }
//
//        let itemWidth = self.bounds.width / CGFloat(itemArray.count + 1)
//
//        for i in 0..<itemArray.count {
//            let tabbarItem = itemArray[i]
//            if tabbarItem.isKind(of: NSClassFromString("UITabBarButton")!) {
//
//                let itemButton = tabbarItem as! UIControl
//                itemButton.tag = i
//
//                var index = i
//                if index >= 2 {
//                    index = index + 1
//                }
//
//                itemButton.frame = CGRect(x: CGFloat(index) * itemWidth, y: 0, width: itemWidth, height: TabBarNormalHeight)
//
//                if self.nowSelectedItem == nil && i == 0 {
//                    self.nowSelectedItem = itemButton
//                }
//            }
//        }

//        if self.addButton == nil {
//            let addButton = UIButton(frame: CGRect(x: 2 * itemWidth, y: 0, width: itemWidth, height: TabBarNormalHeight))
//            addButton.addTarget(self, action: #selector(addButtonClick), for: .touchUpInside)
//            self.addButton = addButton
//        }
//
//        self.addSubview(self.addButton!)
//        self.addButton!.setImage(UIImage(named: "shouye-jia"), for: .normal)
    }
}

extension BaseTabBar {
    @objc fileprivate func addButtonClick() {
         
    }
}
