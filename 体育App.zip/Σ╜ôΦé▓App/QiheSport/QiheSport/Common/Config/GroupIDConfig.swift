//
//  GroupIDConfig.swift
//  Poooli
//
//  Created by lx on 2019/6/12.
//  Copyright © 2019 JYLin. All rights reserved.
//

import UIKit

let bangGroupID = "group.com.poooli.wonderfulprinter"
let poooliGroupID = "group.com.poooli.printer"
let poooliOutsideGroupID = "group.com.poooli.beautifulprinter"

let poooliShareSchemeID = "poooliprint://"
let bangbangShareSchemeID = "pooolibangbang://"
let poooliOutsideShareSechemeID = "poooliOutuside://"

