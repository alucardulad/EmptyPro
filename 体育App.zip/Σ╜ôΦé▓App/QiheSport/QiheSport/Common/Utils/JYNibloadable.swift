//
//  JYNibloadable.swift
//  Poooli
//
//  Created by lx on 2019/2/18.
//  Copyright © 2019 JYLin. All rights reserved.
//

import UIKit

protocol JYNibloadable {


}

extension JYNibloadable where Self : UIView{

    static func loadNib(_ nibNmae :String? = nil) -> Self
    {
        return Bundle.main.loadNibNamed(nibNmae ?? "\(self)", owner: nil, options: nil)?.first as! Self
    }
}

