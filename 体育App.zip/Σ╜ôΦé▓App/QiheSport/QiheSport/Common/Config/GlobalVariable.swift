//
//  GlobalVariable.swift
//  remakeMushu
//
//  Created by 林君扬 on 2017/11/16.
//  Copyright © 2017年 JYangLin. All rights reserved.
//

import Foundation

let Oss_aliyun =  "oss-cn-hangzhou.aliyuncs.com"


#if DEBUG

let BaseUrl =  "http://poooli-test-api.poooli.cn/"

#else

let BaseUrl = "https://poooli-api.poooli.com/"

#endif


/** 用户登录 */
let authorizationsUrl =  BaseUrl + "/overseauser/login/"
