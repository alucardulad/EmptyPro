//
//  PLLocalizationManager.swift
//  Poooli
//
//  Created by dingxiaoshuang on 2019/6/10.
//  Copyright © 2019 JYLin. All rights reserved.
//

import Foundation

let APPLANGUAGE = "APPLANGUAGE"
/// 上面的字段是ISO编码，下面的是后台需要传的值
enum AppLanguage: String, CustomStringConvertible {
    case chinese_simplified = "zh-Hans"
    case english = "en"
    case japanese = "ja"
    case spanish = "es"
    case korean = ""
    
    var description: String {
        switch self {
            case .chinese_simplified: return "0"
            case .english: return "1"
            case .japanese: return "2"
            case .spanish: return "4"
            default: return "3"
        }
    }
}

class PLLocalizationManager: NSObject {
    let userDefalut = UserDefaults.standard
    
    var bundle: Bundle?
    
    var languageLists: [String : String] = [ "中文":AppLanguage.chinese_simplified.rawValue,
                                         "English":AppLanguage.english.rawValue,
                                             "日语":AppLanguage.japanese.rawValue,
                                          "西班牙语":AppLanguage.spanish.rawValue]
    
    static let standard = PLLocalizationManager()
    
    private override init() { }
    
    func initializaForLanguage()  {
        
        var language = PLLocalizationManager.standard.userDefalut.value(forKey: APPLANGUAGE)
        
        if language == nil {
            let currentLanguage = NSLocale.preferredLanguages.first!
            if currentLanguage.hasPrefix(AppLanguage.chinese_simplified.rawValue) {
                language = AppLanguage.chinese_simplified.rawValue
            } else if currentLanguage.hasPrefix(AppLanguage.english.rawValue) {
                language = AppLanguage.english.rawValue
            } else if currentLanguage.hasPrefix(AppLanguage.japanese.rawValue) {
                language = AppLanguage.japanese.rawValue
            }
            else{
                language =  AppLanguage.chinese_simplified.rawValue
            }
            PLLocalizationManager.standard.userDefalut.set(language, forKey: APPLANGUAGE)
        }
        
        PLLocalizationManager.standard.bundle = Bundle.init(path: Bundle.main.path(forResource: (language as! String), ofType: "lproj")!)
    }
    
    func saveCurrentLanguageToUserDefault(language: AppLanguage? = AppLanguage.english) {
        PLLocalizationManager.standard.userDefalut.set(language?.rawValue, forKey: APPLANGUAGE)
        
        PLLocalizationManager.standard.bundle = Bundle.init(path: Bundle.main.path(forResource: language!.rawValue, ofType: "lproj")!)
    }
    
    func getCurrentLangeage() -> AppLanguage {
        return AppLanguage(rawValue: PLLocalizationManager.standard.userDefalut.value(forKey: APPLANGUAGE) as! String ) ?? AppLanguage.chinese_simplified
    }
    
    func cleanCurrentLanguage() {
        PLLocalizationManager.standard.userDefalut.removeObject(forKey: APPLANGUAGE)
    }
}
