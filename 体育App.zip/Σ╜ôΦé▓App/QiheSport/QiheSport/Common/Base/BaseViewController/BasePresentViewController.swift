//
//  BasePresentViewController.swift
//  EmptyPro
//
//  Created by Alucardulad on 2/26/20.
//  Copyright © 2020 Alucardulad. All rights reserved.
//

import UIKit

extension BasePresentViewController {
    override func setUpInterface() {
        self.view.backgroundColor = UIColor.clear
        self.view.addSubview(backgroundView)
    }
}

extension BasePresentViewController {
    @objc func dismissSelf() {
        self.dismiss(animated: true) {
            if self.presentVCDismiss != nil {
                self.presentVCDismiss!()
            }
        }
    }
    
    @objc func backgroundViewClick() {
        self.dismissSelf()
    }
}

class BasePresentViewController: BaseViewController {
    
    var presentVCDismiss: (() -> Void)?
    
    fileprivate lazy var backgroundView: UIView = {
        let backgroundView = UIView(frame: self.view.bounds)
        backgroundView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(backgroundViewClick))
        backgroundView.addGestureRecognizer(tap)
        
        return backgroundView
    }()

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)

        self.modalPresentationStyle = .custom
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override var shouldAutorotate: Bool{
        return false
    }
    
}
