//
//  NetworkingManager.swift
//  QiheSport
//
//  Created by Alucardulad on 2/26/20.
//  Copyright © 2020 Alucardulad. All rights reserved.
//

import UIKit
import Alamofire
import DaisyNet

class NetworkingManager: NSObject {
    var isNetReachable: Bool = true
    
    static let shared: NetworkingManager = NetworkingManager()

    var HeadersParameters = [String:String]()
    private override init() {
        super.init()
    }
}

extension NetworkingManager
{
    func test(){
        DaisyNet.request("www.baidu.com", method: .post, params: HeadersParameters, dynamicParams: HeadersParameters, encoding: URLEncoding.default, headers: HeadersParameters).cache(true).responseCacheAndJson { (value) in
            switch value.result {
            case .success(let json):
                if value.isCacheData {
                    print("我是缓存的")
                } else {
                    print("我是网络的")
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}
