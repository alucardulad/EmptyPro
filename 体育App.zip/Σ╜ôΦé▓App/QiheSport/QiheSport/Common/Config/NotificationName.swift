//
//  NotificationName.swift
//  remakeMushu
//
//  Created by 林君扬 on 2017/12/15.
//  Copyright © 2017年 JYangLin. All rights reserved.
//

import Foundation

let bScaleImagViewInsertTheme = "bScaleImagViewInsertTheme"
