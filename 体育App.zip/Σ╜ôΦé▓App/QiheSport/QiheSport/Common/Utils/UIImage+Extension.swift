//
//  UIImage+Extension.swift
//  Poooli
//
//  Created by 林君杨 on 2018/12/17.
//  Copyright © 2018 JYLin. All rights reserved.
//

import UIKit

/// 旋转方向
///
/// - original: 不变
/// - right: 顺时针90
/// - left: 逆时针90
/// - horizontal: 水平镜像
/// - vertical: 垂直镜像
enum RotateOperation: Int {
    case original = 0
    case right = 1
    case left = 2
    case horizontal = 3
    case vertical = 4
}

extension UIImageView{

    /**

     * param: radius            圆角半径

     * 注意：只有当imageView.image不为nil时，调用此方法才有效果

     */
    func cornerRadius(radius:CGFloat){

        if self.image == nil{
            return
        }

        //开始图形上下文
        UIGraphicsBeginImageContextWithOptions(self.bounds.size, false, UIScreen.main.scale)

        //获取图形上下文
        guard let ctx = UIGraphicsGetCurrentContext() else { return }


        //根据一个rect创建一个椭圆
        ctx.addEllipse(in: self.bounds)


        //裁剪
        ctx.clip()

        //将原照片画到图形上下文
        self.image!.draw(in: self.bounds)

        //从上下文上获取剪裁后的照片
        let newImage = UIGraphicsGetImageFromCurrentImageContext()

        //关闭上下文
        UIGraphicsEndImageContext()

        self.image = newImage
    }
}

extension UIImage {
//    convenience init?(iconNamed name: String, appendName: String = "_bang") {
//        
//        let AppendName = JYTool.getBundleNameSpeace() == bangBundleID ? appendName : ""
//        
//        self.init(named: name + AppendName)
//    }
//    
//    convenience init?(iconNamed name: String, appendName: String = "_bang", suffixName: String) {
//        
//        let AppendName = JYTool.getBundleNameSpeace() == bangBundleID ? appendName : ""
//        
//        self.init(named: name + AppendName + suffixName)
//    }
}

extension UIImage {
    //压缩图片大小，图片kb存储数值
    func compressOriginalImage(size: CGFloat) -> UIImage {
        let kb: CGFloat = size * 1024
        
        var compression: CGFloat = 0.9
        let maxCompression: CGFloat = 0.1
        guard var imageData = self.jpegData(compressionQuality: compression) else {
            return self
        }
        while CGFloat(imageData.count) > kb && compression > maxCompression {
            compression = compression - 0.1
            guard let tempData = self.jpegData(compressionQuality: compression) else {
                return self
            }
            
            imageData = tempData
        }
        return UIImage(data: imageData) ?? self
    }
}

// MARK: -- 图片压缩
extension UIImage {
    //压缩图片大小，图片最大宽度
    func scalingWithMaxWidth(maxWidth: CGFloat) -> UIImage {
        
        let height = (maxWidth * self.size.height) / self.size.width
        
        let newSize = CGSize(width: maxWidth, height: height)
        UIGraphicsBeginImageContext(newSize)
        
        self.draw(in: CGRect(origin: CGPoint.zero, size: newSize))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage ?? self
    }

     //压缩图片大小，图片最大高度
    func scalingWithMaxHeight(MaxHeight: CGFloat) -> UIImage {
        
        let width = (MaxHeight * self.size.width) / self.size.height
        
        let newSize = CGSize(width: width, height: MaxHeight)
        UIGraphicsBeginImageContext(newSize)
        
        self.draw(in: CGRect(origin: CGPoint.zero, size: newSize))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage ?? self
    }
}

extension UIImage {
    
    func contrast(value: Float) -> UIImage {
        return self.setImageParameter(value: value, typeKey: "inputContrast")
    }
    
    fileprivate func setImageParameter(value: Float, typeKey: String) -> UIImage {
        let context = CIContext(options: nil)
        let inputImage = CIImage(image: self)
        guard let filter = CIFilter(name: "CIColorControls") else {
            return self
        }
        filter.setValue(inputImage, forKey: kCIInputImageKey)
        
        filter.setValue(value, forKey: typeKey)
        
        guard let result = filter.value(forKey: kCIOutputImageKey) as? CIImage else {
            return self
        }
        guard let cgImage = context.createCGImage(result, from: result.extent) else {
            return self
        }
        let resultImage = UIImage.init(cgImage: cgImage)
        return resultImage
    }
}

extension UIImage {
    func Urotation() -> UIImage {

        let rotate =  CGFloat.pi * 1.5
        let rect = CGRect(x: 0, y: 0, width: self.size.height, height: self.size.width)
        let translateX: CGFloat = 0
        let translateY = -rect.width
        let scaleY = rect.width / rect.height
        let scaleX = rect.height / rect.width

        UIGraphicsBeginImageContext(rect.size)
        guard let context = UIGraphicsGetCurrentContext() else {
            return self
        }
        context.translateBy(x: 0.0, y: rect.size.height)
        context.scaleBy(x: 1.0, y: -1.0)
        context.rotate(by: rotate)
        context.translateBy(x: translateX, y: translateY)

        context.scaleBy(x: scaleX, y: scaleY)

        context.draw(self.cgImage!, in: CGRect(x: 0, y: 0, width: rect.width, height: rect.height))

        guard let newImage = UIGraphicsGetImageFromCurrentImageContext() else {
            return self
        }

        UIGraphicsEndImageContext()

        return newImage
    }

    func rotation() -> UIImage {
        
        let rotate = CGFloat.pi / 2
        let rect = CGRect(x: 0, y: 0, width: self.size.height, height: self.size.width)
        let translateX: CGFloat = 0
        let translateY = -rect.width
        let scaleY = rect.width / rect.height
        let scaleX = rect.height / rect.width
        
        UIGraphicsBeginImageContext(rect.size)
        guard let context = UIGraphicsGetCurrentContext() else {
            return self
        }
        context.translateBy(x: 0.0, y: rect.size.height)
        context.scaleBy(x: 1.0, y: -1.0)
        context.rotate(by: rotate)
        context.translateBy(x: translateX, y: translateY)
        
        context.scaleBy(x: scaleX, y: scaleY)
        
        context.draw(self.cgImage!, in: CGRect(x: 0, y: 0, width: rect.width, height: rect.height))
        
        guard let newImage = UIGraphicsGetImageFromCurrentImageContext() else {
            return self
        }

        UIGraphicsEndImageContext()
        
        return newImage
    }
    

}

extension UIImage {
    func cutImage(cutRect rect: CGRect, isScale: Bool = false) -> UIImage {
        
        guard let imageRef = self.cgImage?.cropping(to: rect) else {
            return self
        }
        
        let newImage = isScale == true ? UIImage(cgImage: imageRef, scale: UIScreen.main.scale, orientation: UIImage.Orientation.up) : UIImage(cgImage: imageRef)
        
        return newImage
    }
    
    func cutImage(cutRect: CGRect) -> UIImage {
        
        let rect = CGRect(x: cutRect.origin.x * self.scale,
                          y: cutRect.origin.y * self.scale,
                          width: cutRect.size.width * self.scale,
                          height: cutRect.size.height * self.scale)
        
        guard let imageRef = self.cgImage?.cropping(to: rect) else {
            return self
        }
        
        return UIImage(cgImage: imageRef, scale: UIScreen.main.scale, orientation: UIImage.Orientation.up)
    }
    
    func imageWithWhiteBackground(size newImageSize:CGSize) -> UIImage {
        
        UIGraphicsBeginImageContextWithOptions(newImageSize, false, UIScreen.main.scale)

        let ctx = UIGraphicsGetCurrentContext()
        ctx!.setFillColor(UIColor.white.cgColor)
        ctx!.fill(CGRect(x: 0, y: 0, width: newImageSize.width, height: newImageSize.height ))
        ctx?.translateBy(x: 0, y: newImageSize.height)
        ctx?.scaleBy(x: 1.0, y: -1.0)


        ctx?.draw(self.cgImage!,in:CGRect(origin: CGPoint(x:0,y:newImageSize.height - self.size.height), size: self.size))

        guard let resultImage = UIGraphicsGetImageFromCurrentImageContext() else { return UIImage() }
        UIGraphicsEndImageContext()
        
        return resultImage
        
    }
    
    
}

//extension UIImage {
//    func cutImage(cutRect rect: CGRect, isScale: Bool = false) -> UIImage {
//
//        let scale: CGFloat = UIScreen.main.scale
//        let x: CGFloat = rect.origin.x * scale
//        let y: CGFloat = rect.origin.y * scale
//        let w: CGFloat = rect.size.width * scale
//        let h: CGFloat = rect.size.height * scale
//        let dianRect = CGRect.init(x: x, y: y, width: w, height: h)
//        guard let imageRef = self.cgImage?.cropping(to: (isScale == true ? dianRect : rect)) else {
//            return self
//        }
//
//        let newImage = isScale == true ? UIImage(cgImage: imageRef, scale: UIScreen.main.scale, orientation: UIImageOrientation.up) : UIImage(cgImage: imageRef)
//
//        return newImage
//    }
//
//}

extension UIImage {
    
    func mixImage(previousLayerImage image: UIImage, imageSize: CGSize = CGSize.zero) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(self.size, false, 0)
        
        self.draw(in: CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height))
        
        let newImage = image.scalingWithMaxWidth(maxWidth: self.size.width)
        newImage.draw(in: CGRect(x: 0, y: 0, width: newImage.size.width, height: newImage.size.height))

        let returnimage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        return returnimage ?? self
    }
}

// MARK: - 旋转与镜像
extension UIImage {
    func swapWidthAndHeigtht(rect: CGRect) -> CGRect {
        let swapedRect = CGRect(x: rect.origin.x, y: rect.origin.y, width: rect.size.height, height: rect.size.width)
        return swapedRect
    }
    
    func mirroed(orientation: RotateOperation) -> UIImage{
        guard let cgImage = self.cgImage else { return self }
        let rect = CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height)
        UIGraphicsBeginImageContextWithOptions(rect.size, false, self.scale)
        let context = UIGraphicsGetCurrentContext()
        context?.clip(to: rect)
        switch orientation {
        case .original:
            return self
        case .right:
            break
        case .left:
            break
        case .horizontal:
            context?.rotate(by: .pi)
            context?.translateBy(x: -rect.size.width, y: -rect.size.height)
        case .vertical:
            break
        }
        
        context?.draw(cgImage, in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        return newImage ?? self
    }
    
    func rotate(radians: Float) -> UIImage? {
        var newSize = CGRect(origin: CGPoint.zero, size: self.size).applying(CGAffineTransform(rotationAngle: CGFloat(radians))).size
        // Trim off the extremely small float value to prevent core graphics from rounding it up
        newSize.width = floor(newSize.width)
        newSize.height = floor(newSize.height)
        
        UIGraphicsBeginImageContextWithOptions(newSize, false, self.scale)
        let context = UIGraphicsGetCurrentContext()
        
        // Move origin to middle
        context?.translateBy(x: newSize.width/2, y: newSize.height/2)
        // Rotate around middle
        context?.rotate(by: CGFloat(radians))
        // Draw the image at its center
        self.draw(in: CGRect(x: -self.size.width/2, y: -self.size.height/2, width: self.size.width, height: self.size.height))
        
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage
    }

    func setNomalrotate() ->UIImage?{
        var type = 0.0
        switch self.imageOrientation {
        case UIImage.Orientation.up:
              type = 0.0
            break
        case UIImage.Orientation.left:
            type = 1
            break
        case UIImage.Orientation.right:
              type = 4
            break
        case UIImage.Orientation.down:
              type = 3
            break
        default:
            type = 0.0
            break
        }
        return self.rotate(radians: Float(type * .pi))

    }
    
}

extension UIImage {
    class func getImageFromPDF(pdfDocument: CGPDFDocument, size: CGSize, complete: @escaping((_ images: [UIImage]) -> Void)) {
        let pageNum = pdfDocument.numberOfPages
        DispatchQueue.global().async {
            var imageArray: [UIImage] = []
            for page in 1 ... pageNum {
                guard let pdfPage = pdfDocument.page(at: page) else { return }
                let pageRect: CGRect = pdfPage.getBoxRect(CGPDFBox.mediaBox)

                UIGraphicsBeginImageContextWithOptions(pageRect.size, false, UIScreen.main.scale)
                guard let ctx = UIGraphicsGetCurrentContext() else { return }
                
                ctx.setFillColor(UIColor.white.cgColor)
                ctx.fill(CGRect(x: 0, y: 0, width: pageRect.size.width , height: pageRect.size.height ))
                //翻转坐标系
                ctx.translateBy(x: 0, y: pageRect.size.height)
                ctx.scaleBy(x: 1.0, y: -1.0)
                // 映射
                let pdfTranform = pdfPage.getDrawingTransform(.cropBox, rect: CGRect(origin: .zero, size: pageRect.size), rotate: 0, preserveAspectRatio: true)
                ctx.concatenate(pdfTranform)
               
                ctx.drawPDFPage(pdfPage)
                guard let image = UIGraphicsGetImageFromCurrentImageContext() else { return }
                imageArray.append(image)
                UIGraphicsEndImageContext()
            }
            DispatchQueue.main.async {
                complete(imageArray)
            }
        }
    }
}
