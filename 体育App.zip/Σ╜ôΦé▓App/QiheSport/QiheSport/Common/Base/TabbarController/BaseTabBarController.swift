//
//  BaseTabBarController.swift
//  EmptyPro
//
//  Created by Alucardulad on 2/26/20.
//  Copyright © 2020 Alucardulad. All rights reserved.
//

import UIKit
import EachNavigationBar

class BaseTabBarController: UITabBarController {
    private lazy var badgeView: UIView = {
        let badgeView = UIView()
        badgeView.backgroundColor = .red
        badgeView.layer.cornerRadius = 5
        badgeView.layer.masksToBounds = true
        return badgeView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        self.delegate = self
        /// 添加子控制器
        addChildViewControllers()
        
        let newTabbar = BaseTabBar()
        setValue(newTabbar, forKey: "tabBar")
        
//        NotificationCenter.default.addObserver(self, selector: #selector(reloadLanguage),
//                                                         name: NSNotification.Name(rawValue: PLChangeLanguageNotification),
//                                                       object: nil)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        self.reloadLanguage()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}


extension BaseTabBarController {
    /// 添加子控制器
    fileprivate func addChildViewControllers() {
        let fileName = "PoooliTabbarChildController.plist"

        guard let file = Bundle.main.path(forResource: fileName, ofType: nil) else {return}
        guard let json = NSDictionary(contentsOf: URL(fileURLWithPath: file)) else {return}
        
        let jsonData = json["data"]
        
        guard let dataArray = jsonData as? [[String:String]] else {return}
        
        for i in 0..<dataArray.count {
            let dic = dataArray[i]
            childVCSetUpNaVC(viewControllerName: dic["viewController"]!, title: dic["title"]!, nomalImageName: dic["normalImage"]!, selectedImage: dic["selectedImage"]!,tagNum: i)
        }
        
    }
    
    /// 初始化导航控制器
    fileprivate func childVCSetUpNaVC(viewControllerName : String, title : String, nomalImageName : String, selectedImage : String,tagNum:Int) {
        
        guard let vcClass = JYTool.getClassTypeWithClassName(className: viewControllerName) as? UIViewController.Type else {return}
        
        let viewController = vcClass.init()

        viewController.tabBarItem.tag = tagNum

        viewController.tabBarItem.title = title
        
        UITabBar.appearance().tintColor = UIColor.black
        
        if #available(iOS 10.0, *) {
            UITabBar.appearance().unselectedItemTintColor = UIColor.lightGray
        }else{
            viewController.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.lightGray], for: .normal)
        }
        
        viewController.tabBarItem.image = UIImage(named: nomalImageName)
        viewController.tabBarItem.selectedImage = UIImage(named: selectedImage)
        
        let navc = BaseNavigationController(rootViewController: viewController)
        navc.navigation.configuration.isEnabled = true
   
        self.addChild(navc)


    }
    
    @objc private func reloadLanguage() {
//        self.childViewControllers[0].tabBarItem.title = Home.localized()
//        self.childViewControllers.last!.tabBarItem.title = Me.localized()
    }
}

extension BaseTabBarController {
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        var event: String
        
//        switch item.tag {
//            case 0: event = umengEventShouyedaohangDaohang
//            case 1: event = umengEventShouyedaohangFaxian
//            case 2: event = umengEventShouyedaohangSucaiguangchang
//            case 3: event = umengEventShouyedaohangWode
//            default: event = ""
//        }
//        MobClick.event(event)
    }
}

extension BaseTabBarController{
    func showHasMessage(num:Int) {
        if num == 0 {
            self.badgeView.removeFromSuperview()
        } else {
            let index = (CGFloat(self.tabBar.items!.count) + 0.65) / CGFloat(self.tabBar.items!.count + 1)
            let x = ceil((index * self.tabBar.frame.width))
            let y = ceil(0.1 * self.tabBar.frame.height)
            self.badgeView.frame = CGRect(x: x, y: y, width: 10, height: 10)
            self.tabBar.addSubview(self.badgeView)
        }
    }
}
