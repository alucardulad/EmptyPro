//
//  EventStringConfig.swift
//  Poooli
//
//  Created by 林君扬 on 2019/2/19.
//  Copyright © 2019 JYLin. All rights reserved.
//

import Foundation


// MARK: --------------------------- 导航 ------------------------------
/// .导航.首页
let umengEventShouyedaohangDaohang = ".shouyedaohang.daohang"
/// .导航.发现
let umengEventShouyedaohangFaxian = ".shouyedaohang.faxian"
/// .导航.素材广场
let umengEventShouyedaohangSucaiguangchang = ".shouyedaohang.sucaiguangchang"
/// .导航.我的
let umengEventShouyedaohangWode = ".shouyedaohang.wode"
/// .导航.动态发布
let umengEventShouyedaohangDongtaifabu = ".shouyedaohang.dongtaifabu"
