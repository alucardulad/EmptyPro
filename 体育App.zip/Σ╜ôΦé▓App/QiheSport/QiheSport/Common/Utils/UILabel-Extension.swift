
//
//  UILabel-Extension.swift
//  Example
//
//  Created by brian on 2018/4/26.
//  Copyright © 2018年 Brian Inc. All rights reserved.
//

import UIKit

extension UILabel {
    
    var sf : UILabelExtension {
        return UILabelExtension(label: self)
    }
}

struct UILabelExtension {
    
    internal let label : UILabel
    
    internal init(label: UILabel) {
        self.label = label
    }
    
    /// 设置Label的行间距和字间距
    ///
    /// - Parameters:
    ///   - lineSpace: 行间距
    ///   - wordSpace: 字间距
    func changeLabelRowSpace(lineSpace: CGFloat, wordSpace: CGFloat) {
        guard let content = label.text else {return}
        let attributedString : NSMutableAttributedString = NSMutableAttributedString(string: content)
        let paragraphStyle : NSMutableParagraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = lineSpace
        attributedString.addAttribute(NSAttributedString.Key.paragraphStyle, value: paragraphStyle, range: NSMakeRange(0, (content.utf16.count)))
        attributedString.addAttribute(NSAttributedString.Key.kern, value: wordSpace, range: NSMakeRange(0, (content.count)))
        label.attributedText = attributedString
        label.sizeToFit()
    }

    func changeLabellineSpace(lineSpace: CGFloat) {
        guard let content = label.text else {return}
        let attributedString : NSMutableAttributedString = NSMutableAttributedString(string: content)
        let paragraphStyle : NSMutableParagraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = lineSpace
        attributedString.addAttribute(NSAttributedString.Key.paragraphStyle, value: paragraphStyle, range: NSMakeRange(0, (content.utf16.count)))
        label.attributedText = attributedString
        label.sizeToFit()
    }
    
    
    /// 指定Label显示的字的个数
    ///
    /// - Parameter number: 个数
    func specifiesTheNumberOfWordsToDisplay(number: Int) {
        guard let content = label.text else {return}
        let attributedString : NSMutableAttributedString = NSMutableAttributedString(string: content)
        if content.count < number {return}
        attributedString.deleteCharacters(in: NSMakeRange(number, content.count - number))
        label.attributedText = attributedString
        label.sizeToFit()
    }
}
extension UILabel {
    //判断文本标签的内容是否被截断
    var isTruncated: Bool {
        guard let labelText = text else {
            return false
        }

        //计算理论上显示所有文字需要的尺寸
        let rect = CGSize(width: self.bounds.width, height: CGFloat.greatestFiniteMagnitude)
        let labelTextSize = (labelText as NSString)
            .boundingRect(with: rect, options: .usesLineFragmentOrigin,
                          attributes: [NSAttributedString.Key.font: self.font], context: nil)

        //计算理论上需要的行数
        let labelTextLines = Int(ceil(CGFloat(labelTextSize.height) / self.font.lineHeight))

        //实际可显示的行数
        var labelShowLines = self.numberOfLines
        if self.numberOfLines != 0 {
            labelShowLines = min(labelShowLines, self.numberOfLines)
        }
        //比较两个行数来判断是否需要截断
        return labelTextLines > labelShowLines
    }
}
