//
//  UIColor+Hex.swift
//  popo
//
//  Created by 林君扬 on 2016/12/24.
//  Copyright © 2016年 linjunyang. All rights reserved.
//

import UIKit

extension UIColor{
    class func colorWithRGB(red : CGFloat, green : CGFloat, blue : CGFloat, alpha: CGFloat = 1.00) -> UIColor {
        return UIColor(red: red / 255.0, green: green / 255.0, blue: blue / 255.0, alpha: alpha)
    }
    
    class func colorWithString(colorString : String) -> UIColor {
        var colorString = colorString
        colorString = colorString.uppercased()
        //  删除字符串中的空格
        colorString = colorString.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines).uppercased()
        
        if colorString.count == 8 && colorString.hasPrefix("0X") {
            
            var range = NSRange()
            range.length = 2
            range.location = 2
            //  r
            let rString = (colorString as NSString).substring(with: range)
            
            //  g
            range.location = 4
            let gString = (colorString as NSString).substring(with: range)
            
            //  b
            range.location = 6
            let bString = (colorString as NSString).substring(with: range)
            
            // 进制转换
            let r = changeToCGFloat(num: rString)
            let g = changeToCGFloat(num: gString)
            let b = changeToCGFloat(num: bString)
            
            return UIColor(red: r / 255.0, green: g / 255.0, blue: b / 255.0, alpha: 1)
        }else{
            return UIColor.clear
        }
    }
    
    class func colorWithStringAlpha(colorString : String) -> UIColor {
        var colorString = colorString
        colorString = colorString.uppercased()
        //  删除字符串中的空格
        colorString = colorString.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines).uppercased()
        
        if colorString.count == 10 && colorString.hasPrefix("0X") {
            
            var range = NSRange()
            range.length = 2
            range.location = 2
            //  r
            let rString = (colorString as NSString).substring(with: range)
            
            //  g
            range.location = 4
            let gString = (colorString as NSString).substring(with: range)
            
            //  b
            range.location = 6
            let bString = (colorString as NSString).substring(with: range)
            
            //  a
            range.location = 8
            let aString = (colorString as NSString).substring(with: range)
            // 进制转换
            let r = changeToCGFloat(num: rString)
            let g = changeToCGFloat(num: gString)
            let b = changeToCGFloat(num: bString)
            let a = changeToCGFloat(num: aString)
            
            return UIColor(red: r / 255.0, green: g / 255.0, blue: b / 255.0, alpha: a/255.0)
        }else{
            return UIColor.clear
        }
    }
    
    static func changeToCGFloat(num:String) -> CGFloat {
        let str = num.uppercased()
        var sum = 0
        for i in str.utf8 {
            sum = sum * 16 + Int(i) - 48 // 0-9 从48开始
            if i >= 65 {                 // A-Z 从65开始，但有初始值10，所以应该是减去55
                sum -= 7
            }
        }
        return CGFloat(sum)
    }
}

extension UIColor {
    class func randomColor() -> UIColor {
        let r = arc4random() % 255
        let g = arc4random() % 255
        let b = arc4random() % 255
        return UIColor.colorWithRGB(red: CGFloat(r), green: CGFloat(g), blue: CGFloat(b))
    }
}

extension UIColor {
    func creatImageWithColor(imageSize: CGSize = CGSize.zero) -> UIImage {
        let size = imageSize == CGSize.zero ? CGSize(width: 999, height: 999) : imageSize
        let rect = CGRect.init(x: 0, y: 0, width: size.width, height: size.height)
        UIGraphicsBeginImageContext(rect.size)
        let context = UIGraphicsGetCurrentContext()
        context!.setFillColor(self.cgColor)
        context!.fill(rect)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
}
